PC Section

		Note: all reference to SP-808 also includes SP-808EX
CONTENTS 
I. System requirements
II. Installing the software
III. Hardware (Zip drive) connection
IV. Operation
	a. Starting the application
	b. Quitting the application
	c. Selecting the drive
	d. Selecting the sample bank
	e. Converting a SP-808 formatted sample into a .wav or AIFF file
	f. Converting a .wav or AIFF file into SP-808 formatted sample
	g. Playing the samples
	h. Pad Bank Name.




I. System requirements:
	Zip drive
	faster than 80486 (Pentium recommended)
	Windows95/98

	for Pad Play function:
	Pentium 133Hz or faster
	Sound device which supports 44.1kHz/Stereo


II. Installing the Software
	1. Insert the CD-ROM disk containing the application software into the disk drive.
	2. Double-click the CD-ROM disk icon and "converter_win" folder will be displayed.
	3. Drag "sp808wav.exe" from "converter_win" folder to the hard disk.


III. Hardware (Zip drive) connection*
	1. With the power for the Zip drive and the computer turned off, connect the
	   computer and Zip drive with the supplied cable and turn the Zip drive on.
	2. Turn on the computer.
	* Please refer to the owner's manuals of the Zip drive and computer for more details.

	Note: If the message "Do you want to initialize the disk?" appears, eject the disk and
	check if the driver software for the Zip drive is installed. Also, make sure that the Zip
	disk you are using is an SP-808 formatted disk. If you are using a blank Zip disk, you
	must format it with the SP-808 first.


IV. Operation
	a. Start the application by double-clicking on the "sp808wav.exe" icon. The
	   application will start and automatically search for a SP-808 formatted Zip disk.
	b. Quit the application by selecting "Exit" from the File menu.
	c. Select the desired drive by clicking in the "SP-808 Drive" pop-up menu. If a
	   SP-808 formatted disk is inserted in the selected drive, the contents of Sample
	   Bank#1 will be displayed.

	<If a SP-808 formatted disk is not inserted in the selected drive, pads with "X"
	will be displayed.>

	d. Select a sample bank by clicking in the "SP-808 Bank Select" pop-up menu
	   and highlighting the desired bank. The contents of the selected sample bank will
	   be displayed.

	<Sample banks are displayed with "bank number" and "bank name.">

	e. Use the following procedure to convert an SP-808 formatted sample into a
	   .WAV file*:

		1. Click on the pad that contains the sample you wish to convert (it will be
		   highlighted).Pads with samples assigned to them are red and blank pads
		   are white.
		2. Press the "SP-808->.wav" button and the "Save As" window will be
		   displayed. Use the "Save In" window and pop-up menu to select the
		   destination for the file. You can rename the file in the "File Name" window
		   and select Wave Files (.wav) in the "Save as type" window.
		3. Click on the "Save" button to save the file.
		*The time to convert/save the file varies with the size of the original sample.
		Click "Cancel" to abort the conversion.

	f. Use the following procedure to convert a .wav file into a SP-808 formatted
	   sample and store it on a pad:
		1. Click on the pad that you would like to use to store the sample (it will
		   be highlighted). Pads with samples assigned to them are red and blank
		   pads are white.
	<It is possible to select a red pad that already contains a sample. In that
	case, the current sample will be replaced with the file you are saving.>

		2. Press the ".wav->SP-808" button and the "Open File" window will be
		   displayed*. Use the "Look In" window and pop-up menu to highlight the
		   .wav file you wish to use.
		3. Click on the "Open" button to convert the selected file into SP-808 for
		   mat and store it to the selected pad.

	Note: If the message "Not Wave File" appears, the selected file is not in .wav format,
	and could not be loaded. Select a .wav file and try again.

	g. Playing the samples.
	You can play back a sample by double-clicking on the pad that it is assigned to.
	Samples can also be played by pressing "Ctrl+P." Click "Cancel" to stop play
	back.

	h. Pad Bank Name.
	You can name the banks on a SP-808 disk using this software.
		1. Click on the Edit Menu
		2. Click on Bank Name
		3. The display for Bank Name appears on your screen. It will be the
		   current bank you have selected.
		4. Type in the name for the bank. You can type in up to 10 characters for
		   the Bank Name.

	<After typing in the name, click the OK button. The display for the Bank name
	will show the new name.>

	Note: If the sample skips or does not play back correctly, make sure that your
	computer meets the minimum requirements for pad play as stated at the beginning.

