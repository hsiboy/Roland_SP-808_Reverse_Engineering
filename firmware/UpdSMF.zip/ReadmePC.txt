Directions for using UpdateSMF

This is an application for playing back Standard MIDI Files that
can be used in place of a full-featured sequencer or librarian 
program. This application is only available for IBM compatible 
computers at this time. You will need a MIDI interface on your
computer to use this program.

Here is the procedure to use this application:

1) Copy the file "updateSMF.exe" to your computer.
2) Launch the application by double clicking on the appropriate icon.
3) Click on the arrow by MIDI Out Device and select the MIDI output
   you wish to use.
4) Click on Path and use the browse dialog box to locate the 
   Standard MIDI Files you have downloaded (they should be in a 
   directory by themselves) and click on OK.
5) Click on Scan SMF, you should see a number of files appear
   in the window immediately next to this button.
6) Press SEND to begin transmitting the files. The application
   will send all of the files sequentially.
7) When the update is completed, press Exit.

(c)1999 Roland Corporation U.S.